import numpy as np
from gym.envs.classic_control.mountain_car import MountainCarEnv
from gym.envs.registration import register
import math

class MountainCarInformativeRewardEnv(MountainCarEnv):
    def __init__(self):
        super().__init__()

    def step(self, action, k=1):
        assert self.action_space.contains(action), "%r (%s) invalid" % (action, type(action))

        position, velocity = self.state
        velocity += (action-1)*0.001 + math.cos(3*position)*(-0.0025)
        velocity = np.clip(velocity, -self.max_speed, self.max_speed)
        position += velocity
        position = np.clip(position, self.min_position, self.max_position)
        if (position==self.min_position and velocity<0): velocity = 0

        done = bool(position >= self.goal_position)
        # Adjust reward based on car position
        reward = (position + 0.5)
        
        # Adjust reward for task completion
        if position >= 0.5:
            reward += 1

        # reward = -1        

        self.state = (position, velocity)
        
        return np.array(self.state), reward, done, {} 

register(
    id='MountainCarInformativeReward-v0',
    entry_point='MountainCarInformativeReward:MountainCarInformativeRewardEnv',
    max_episode_steps=200,
)
