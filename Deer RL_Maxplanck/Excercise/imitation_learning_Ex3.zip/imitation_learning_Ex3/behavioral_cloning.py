

import argparse
import gym
import numpy as np
import pickle
import tensorflow as tf

MAX_STEPS = 100

def load_data(filename):
    with open(filename, 'rb') as f:
        data = pickle.loads(f.read())

    features = data['observations']
    labels = data['actions']
    returns = data['returns']
    labels = np.squeeze(labels, axis=1) # remove extra middle dimension

    # ensure number of features and labels are the same
    assert features.shape[0] == labels.shape[0]

    return features, labels, returns

def build_dataset(features, labels, batch_size=32):
    features_placeholder = tf.placeholder(features.dtype, features.shape)
    labels_placeholder = tf.placeholder(labels.dtype, labels.shape)
    size = features.shape[0]
    dataset = tf.data.Dataset.from_tensor_slices((features_placeholder[:size*10//9], labels_placeholder[:size*10//9]))
    dataset = dataset.shuffle(buffer_size=100000)
    dataset = dataset.batch(batch_size)
    dataset = dataset.repeat()

    iterator = dataset.make_initializable_iterator()

    # val_set = tf.data.Dataset.from_tensor_slices((features_placeholder[size*10//9:], labels_placeholder[size*10//9:]))
    # val_set = dataset.shuffle(buffer_size=100000)
    # val_set = dataset.batch(size*10//9)
    # val_set = dataset.repeat()
    # val_iterator = val_set.make_initializable_iterator()

    return iterator, features_placeholder, labels_placeholder

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--environment', type=str, default="Reacher-v2")
    parser.add_argument('--batch_size', type=int, default=32)
    parser.add_argument('--num_epochs', type=int, default=20)
    parser.add_argument('--num_units', type=int, default=128)
    parser.add_argument('--num_rollouts', type=int, default=10)
    args = parser.parse_args()

    environment = args.environment
    batch_size = args.batch_size
    num_units = args.num_units

    features, labels, expert_returns = load_data(f"./expert_data/{environment}.pkl")
    iterator, features_placeholder, labels_placeholder = build_dataset(features, labels, batch_size)

    x, y = iterator.get_next()

    # implement neural network here.
    # HINT use: out = tf.layers.dense(input, units=..., activation=tf.nn.relu)
    # for each layer and use 2 hidden layers

    y_pred = # output of network

    loss = tf.losses.mean_squared_error(labels=y, predictions=y_pred)
    optimizer = tf.train.AdamOptimizer(1e-3)
    train = optimizer.minimize(loss)

    env = gym.make(environment)

    with tf.Session() as sess:
        sess.run(tf.global_variables_initializer())

        sess.run(iterator.initializer, feed_dict={features_placeholder: features, labels_placeholder: labels})

        # implement training:
        #  args.num_epochs times over the dataset using the required number of batches
        # use:  _, loss_value = sess.run((train, loss))
        # to perform one training step and obtain the current loss value

        # run the environment for num_rollouts using the new policy
        # use:   action = sess.run(y_pred, feed_dict={x: np.expand_dims(obs, axis=0)})
        # to call the network

        # output statistics etc

if __name__ == '__main__':
    main()
