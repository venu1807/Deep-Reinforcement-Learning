import numpy as np

class LQRPolicy:
    def __init__(self, env, eps_expl=0.0):
        self.K = np.asarray([[112.19106357,  23.05097558]])
        self.eps_expl = eps_expl
        self.env = env
        
    def get_action(self, x):
        
        th, thdot = x
        
        if np.random.rand() < self.eps_expl:
            u = env.action_space.sample().reshape(1,1)
            u = u.reshape(1,1)
        else:
            u = np.dot(-self.K, [th, thdot])
            
        return u[0]
