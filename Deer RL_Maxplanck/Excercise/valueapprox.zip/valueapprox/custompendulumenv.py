import numpy as np
from gym.envs.classic_control.pendulum import PendulumEnv
from gym.envs.registration import register

class CustomPendulumEnv(PendulumEnv):
    def __init__(self):
        super().__init__()
        super().reset()
        
        self.Q = np.diag([10, 0.1 ])
        self.R = 0.0001
        
    def step(self, action):
        super().step([action])
        state = self.state
        cost = np.dot( np.dot(state, self.Q), state) + self.R*action**2 
                      
        return state, np.squeeze(cost), False, {}
    
    def reset(self):
        state = [2*(np.random.rand()-0.5)*np.pi, np.random.rand()*self.observation_space.high[2]]
        self.state = state
        
        return state

register(
    id='CustomPendulum-v0',
    entry_point='custompendulumenv:CustomPendulumEnv',
    max_episode_steps=200,
)
